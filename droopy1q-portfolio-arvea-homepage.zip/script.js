const revealItems = document.querySelectorAll(".reveal");

const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            observer.unobserve(entry.target);
        }
    });
}, { threshold: 0.12 });

revealItems.forEach(item => observer.observe(item));

const nav = document.querySelector(".nav");

window.addEventListener("scroll", () => {
    nav.style.background = window.scrollY > 50
        ? "rgba(245,245,243,.92)"
        : "rgba(245,245,243,.78)";
}, { passive: true });

document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", event => {
        const targetId = link.getAttribute("href");
        if (targetId === "#") {
            event.preventDefault();
            window.scrollTo({top: 0, behavior: "smooth"});
            return;
        }
        const target = document.querySelector(targetId);
        if (!target) return;
        event.preventDefault();
        window.scrollTo({
            top: target.getBoundingClientRect().top + window.scrollY - 70,
            behavior: "smooth"
        });
    });
});

window.addEventListener("DOMContentLoaded", () => {
    document.querySelector(".hero-content").animate(
        [
            {opacity: 0, transform: "translateY(30px)"},
            {opacity: 1, transform: "translateY(0)"}
        ],
        {duration: 1000, easing: "cubic-bezier(.22,1,.36,1)", fill: "forwards"}
    );
});
